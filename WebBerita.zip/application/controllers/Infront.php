<?php

class Infront extends CI_Controller 
{
    public function index()
    {
        # code...
    }
}
